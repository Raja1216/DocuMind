from __future__ import annotations

from abc import ABC, abstractmethod

from src.models.document import Document


class AnalysisPass(ABC):
    """
    Base class for all analysis passes.
    """

    @abstractmethod
    def analyze(self, document: Document) -> None:
        pass