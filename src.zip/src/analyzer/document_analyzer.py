from src.analyzer.document_statistics_analyzer import DocumentStatisticsAnalyzer
from src.analyzer.heading_detector import HeadingDetector
from src.analyzer.paragraph_analyzer import ParagraphAnalyzer


class DocumentAnalyzer:

    def __init__(self):

        self.passes = [

            DocumentStatisticsAnalyzer(),

            HeadingDetector(),

            ParagraphAnalyzer(),
        ]

    def analyze(self, document):

        for analysis_pass in self.passes:

            analysis_pass.analyze(document)