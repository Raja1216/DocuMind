from docx import Document as WordDocument
from docx.shared import Pt

from src.models.enums.block_type import BlockType
from src.exporter.builders.run_builder import RunBuilder
from docx.enum.text import WD_ALIGN_PARAGRAPH


class DocxExporter:
    """
    Exports the analyzed document model to a DOCX file.
    """

    @staticmethod
    def export(document, output_path):

        doc = WordDocument()

        total_pages = len(document.pages)

        for page_index, page in enumerate(document.pages):

            for block in page.blocks:

                # Skip empty blocks
                has_text = any(
                    span.text.strip()
                    for line in block.lines
                    for span in line.spans
                )

                if not has_text:
                    continue

                # Skip page numbers
                if block.block_type == BlockType.PAGE_NUMBER:
                    continue

                for para in block.paragraphs:

                    # Create Word paragraph
                    if block.block_type == BlockType.HEADING:
                        word_paragraph = doc.add_heading(level=1)
                    else:
                        word_paragraph = doc.add_paragraph()
                        
                    # <-- Alignment would be applied HERE
                    style = para.style
                
                    if style.alignment == "center":
                        word_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                
                    elif style.alignment == "right":
                        word_paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
                
                    else:
                        word_paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT    
                
                    # Render text
                    for line_index, line in enumerate(para.lines):

                        runs = RunBuilder.build(line)

                        for text_run in runs:

                            run = word_paragraph.add_run(text_run.text)

                            font = run.font
                            font.size = Pt(text_run.font_size)
                            font.name = text_run.font_name

                            run.bold = text_run.bold
                            run.italic = text_run.italic

                        # Preserve spacing between reconstructed PDF lines
                        if line_index < len(para.lines) - 1:
                            word_paragraph.add_run(" ")

            # Preserve page boundaries
            if page_index < total_pages - 1:
                doc.add_page_break()

        doc.save(output_path)