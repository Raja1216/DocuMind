from __future__ import annotations

from docx import Document as WordDocument
from docx.dml.color import RGBColor as WordRGBColor
from docx.enum.section import WD_SECTION
from docx.enum.text import WD_LINE_SPACING
from docx.enum.text import WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt
from docx.text.paragraph import Paragraph
from lxml import etree
from io import BytesIO

from src.exporter.font_name_resolver import (
    FontNameResolver,
)


class FixedLayoutDocxExporter:
    """
    Export a PDF document model as a fixed-layout DOCX.

    Every visible PDF text span is placed inside an
    absolutely positioned Word text box.

    This mode prioritizes visual fidelity and original
    pagination over normal Word paragraph reflow.
    """

    VML_NAMESPACE = (
        "urn:schemas-microsoft-com:vml"
    )

    OFFICE_NAMESPACE = (
        "urn:schemas-microsoft-com:office:office"
    )

    WORD_2003_NAMESPACE = (
        "urn:schemas-microsoft-com:office:word"
    )

    WORD_NAMESPACE = (
        "http://schemas.openxmlformats.org/"
        "wordprocessingml/2006/main"
    )
    
    RELATIONSHIPS_NAMESPACE = (
        "http://schemas.openxmlformats.org/"
        "officeDocument/2006/relationships"
    )

    VML_NAMESPACE_MAP = {
        "v": VML_NAMESPACE,
        "o": OFFICE_NAMESPACE,
        "w10": WORD_2003_NAMESPACE,
        "w": WORD_NAMESPACE,
        "r": RELATIONSHIPS_NAMESPACE,
    }
    
    TEXTBOX_WIDTH_PADDING = 3.0
    TEXTBOX_HEIGHT_PADDING = 6.0

    TEXTBOX_TOP_ADJUSTMENT = 1.5
    LINE_HEIGHT_FACTOR = 1.25

    ANCHOR_FONT_SIZE = 1.0
    ANCHOR_LINE_SPACING = 1.0
    
    TABLE_BORDER_COLOR = "#000000"
    TABLE_BORDER_WIDTH = "0.75pt"

    TABLE_CELL_HORIZONTAL_PADDING = 2.0
    TABLE_CELL_VERTICAL_PADDING = 1.0

    DEFAULT_TABLE_FONT = "Arial"
    DEFAULT_TABLE_FONT_SIZE = 9.0

    TABLE_Z_INDEX = 100
    TEXT_Z_INDEX = 251659264
    IMAGE_Z_INDEX = 1

    _shape_id = 1

    @staticmethod
    def export(
        document,
        output_path: str,
    ) -> None:
        word_document = WordDocument()

        FixedLayoutDocxExporter._shape_id = 1

        for page_index, page in enumerate(
            document.pages
        ):
            section = (
                FixedLayoutDocxExporter
                ._prepare_page_section(
                    word_document=word_document,
                    page_index=page_index,
                )
            )

            FixedLayoutDocxExporter._configure_section(
                section=section,
                page=page,
            )

            anchor_paragraph = (
                FixedLayoutDocxExporter
                ._create_anchor_paragraph(
                    word_document
                )
            )

            FixedLayoutDocxExporter._render_page(
                word_document=word_document,
                anchor_paragraph=anchor_paragraph,
                page=page,
            )

        word_document.save(
            output_path
        )

    @staticmethod
    def _prepare_page_section(
        word_document,
        page_index: int,
    ):
        """
        Use the original first section for page 1.

        Every later PDF page gets a new Word section
        beginning on a new page.
        """

        if page_index == 0:
            return word_document.sections[0]

        return word_document.add_section(
            WD_SECTION.NEW_PAGE
        )

    @staticmethod
    def _configure_section(
        section,
        page,
    ) -> None:
        """
        Match the PDF page dimensions.

        Fixed-layout positioning is relative to the physical
        page, so all Word margins are set to zero.
        """

        section.page_width = Pt(
            page.bbox.width
        )

        section.page_height = Pt(
            page.bbox.height
        )

        zero = Pt(0)

        section.left_margin = zero
        section.right_margin = zero
        section.top_margin = zero
        section.bottom_margin = zero

        section.header_distance = zero
        section.footer_distance = zero
        section.gutter = zero

    @staticmethod
    def _create_anchor_paragraph(
        word_document,
    ):
        """
        Create a minimal paragraph that owns all floating
        text boxes on the current Word page.
        """

        paragraph = word_document.add_paragraph()

        paragraph_format = paragraph.paragraph_format

        paragraph_format.space_before = Pt(0)
        paragraph_format.space_after = Pt(0)

        paragraph_format.line_spacing_rule = (
            WD_LINE_SPACING.EXACTLY
        )

        paragraph_format.line_spacing = Pt(
            FixedLayoutDocxExporter
            .ANCHOR_LINE_SPACING
        )

        anchor_run = paragraph.add_run("")

        anchor_run.font.size = Pt(
            FixedLayoutDocxExporter
            .ANCHOR_FONT_SIZE
        )

        return paragraph

    @staticmethod
    def _render_page(
        word_document,
        anchor_paragraph,
        page,
    ) -> None:
        """
        Render all supported page elements in fixed layout.

        Layer order:
        1. Images
        2. Tables
        3. Normal text
        """

        for image in page.images:
            FixedLayoutDocxExporter._add_image_shape(
                document_part=word_document.part,
                anchor_paragraph=anchor_paragraph,
                image=image,
            )

        for table in page.tables:
            FixedLayoutDocxExporter._render_table(
                anchor_paragraph=anchor_paragraph,
                page=page,
                table=table,
            )

        for block in page.blocks:
            for line in block.lines:
                for span in line.spans:

                    if not span.text.strip():
                        continue

                    if (
                        FixedLayoutDocxExporter
                        ._span_is_inside_any_table(
                            span=span,
                            tables=page.tables,
                        )
                    ):
                        continue

                    FixedLayoutDocxExporter._add_span_textbox(
                        anchor_paragraph=anchor_paragraph,
                        span=span,
                    )

    @staticmethod
    def _render_table(
        anchor_paragraph,
        page,
        table,
    ) -> None:
        """
        Render every detected table cell as an absolutely
        positioned bordered text box.
        """

        for cell in table.cells:

            reference_span = (
                FixedLayoutDocxExporter
                ._find_reference_span_for_cell(
                    page=page,
                    cell=cell,
                )
            )

            FixedLayoutDocxExporter._add_table_cell_shape(
                anchor_paragraph=anchor_paragraph,
                cell=cell,
                reference_span=reference_span,
            )

    @staticmethod
    def _add_table_cell_shape(
        anchor_paragraph,
        cell,
        reference_span,
    ) -> None:
        """
        Add one positioned table cell with border and text.
        """

        width = max(
            cell.right - cell.left,
            1.0,
        )

        height = max(
            cell.bottom - cell.top,
            1.0,
        )

        shape_id = (
            FixedLayoutDocxExporter._next_shape_id()
        )

        shape = (
            FixedLayoutDocxExporter
            ._create_table_cell_shape(
                shape_id=shape_id,
                left=cell.left,
                top=cell.top,
                width=width,
                height=height,
            )
        )

        textbox = (
            FixedLayoutDocxExporter
            ._create_vml_element(
                "textbox"
            )
        )

        textbox.set(
            "inset",
            (
                f"{FixedLayoutDocxExporter.TABLE_CELL_HORIZONTAL_PADDING}pt,"
                f"{FixedLayoutDocxExporter.TABLE_CELL_VERTICAL_PADDING}pt,"
                f"{FixedLayoutDocxExporter.TABLE_CELL_HORIZONTAL_PADDING}pt,"
                f"{FixedLayoutDocxExporter.TABLE_CELL_VERTICAL_PADDING}pt"
            ),
        )

        textbox_content = OxmlElement(
            "w:txbxContent"
        )

        paragraph_element = OxmlElement(
            "w:p"
        )

        textbox_content.append(
            paragraph_element
        )

        textbox.append(
            textbox_content
        )

        shape.append(
            textbox
        )

        pict = OxmlElement(
            "w:pict"
        )

        pict.append(
            shape
        )

        anchor_run = anchor_paragraph.add_run()

        anchor_run._r.append(
            pict
        )

        text_paragraph = Paragraph(
            paragraph_element,
            anchor_paragraph._parent,
        )

        FixedLayoutDocxExporter._configure_table_cell_paragraph(
            text_paragraph
        )

        FixedLayoutDocxExporter._add_table_cell_text(
            text_paragraph=text_paragraph,
            text=cell.text,
            reference_span=reference_span,
        )

    @staticmethod
    def _create_table_cell_shape(
        shape_id: int,
        left: float,
        top: float,
        width: float,
        height: float,
    ):
        """
        Create one bordered VML rectangle representing
        a detected PDF table cell.
        """

        shape = (
            FixedLayoutDocxExporter
            ._create_vml_element(
                "shape"
            )
        )

        shape.set(
            "id",
            f"DocuMindTableCell{shape_id}",
        )

        shape.set(
            "type",
            "#_x0000_t202",
        )

        shape.set(
            "filled",
            "f",
        )

        shape.set(
            "stroked",
            "t",
        )

        shape.set(
            "strokecolor",
            FixedLayoutDocxExporter.TABLE_BORDER_COLOR,
        )

        shape.set(
            "strokeweight",
            FixedLayoutDocxExporter.TABLE_BORDER_WIDTH,
        )

        shape.set(
            (
                f"{{"
                f"{FixedLayoutDocxExporter.OFFICE_NAMESPACE}"
                f"}}allowincell"
            ),
            "f",
        )

        style = (
            "position:absolute;"
            f"margin-left:{left:.3f}pt;"
            f"margin-top:{top:.3f}pt;"
            f"width:{width:.3f}pt;"
            f"height:{height:.3f}pt;"
            f"z-index:{FixedLayoutDocxExporter.TABLE_Z_INDEX};"
            "mso-position-horizontal-relative:page;"
            "mso-position-vertical-relative:page;"
            "mso-wrap-style:none;"
        )

        shape.set(
            "style",
            style,
        )

        wrap = (
            FixedLayoutDocxExporter
            ._create_word_2003_element(
                "wrap"
            )
        )

        wrap.set(
            "type",
            "none",
        )

        shape.append(
            wrap
        )

        return shape

    @staticmethod
    def _configure_table_cell_paragraph(
        text_paragraph,
    ) -> None:
        """
        Remove Word's default spacing inside table cells.
        """

        paragraph_format = (
            text_paragraph.paragraph_format
        )

        paragraph_format.space_before = Pt(0)
        paragraph_format.space_after = Pt(0)

        paragraph_format.left_indent = Pt(0)
        paragraph_format.right_indent = Pt(0)
        paragraph_format.first_line_indent = Pt(0)

        paragraph_format.line_spacing_rule = (
            WD_LINE_SPACING.SINGLE
        )

    @staticmethod
    def _add_table_cell_text(
        text_paragraph,
        text: str,
        reference_span,
    ) -> None:
        """
        Add extracted cell text while preserving the nearest
        available PDF typography.
        """

        lines = text.splitlines()

        if not lines:
            lines = [""]

        for line_index, line_text in enumerate(lines):

            run = text_paragraph.add_run(
                line_text
            )

            if reference_span is not None:

                run.font.size = Pt(
                    reference_span.font_size
                )

                FixedLayoutDocxExporter._apply_font_name(
                    run=run,
                    pdf_font_name=reference_span.font,
                )

                run.font.color.rgb = WordRGBColor(
                    reference_span.color.red,
                    reference_span.color.green,
                    reference_span.color.blue,
                )

                run.bold = (
                    FixedLayoutDocxExporter
                    ._is_bold(reference_span.flags)
                )

                run.italic = (
                    FixedLayoutDocxExporter
                    ._is_italic(reference_span.flags)
                )

            else:
                run.font.size = Pt(
                    FixedLayoutDocxExporter
                    .DEFAULT_TABLE_FONT_SIZE
                )

                FixedLayoutDocxExporter._apply_font_name(
                    run=run,
                    pdf_font_name=(
                        FixedLayoutDocxExporter
                        .DEFAULT_TABLE_FONT
                    ),
                )

            if line_index < len(lines) - 1:
                run.add_break(
                    WD_BREAK.LINE
                )

    @staticmethod
    def _find_reference_span_for_cell(
        page,
        cell,
    ):
        """
        Find the first visible PDF span whose center lies
        inside the detected table cell.
        """

        for block in page.blocks:
            for line in block.lines:
                for span in line.spans:

                    if not span.text.strip():
                        continue

                    center_x = (
                        span.left + span.right
                    ) / 2

                    center_y = (
                        span.top + span.bottom
                    ) / 2

                    if (
                        cell.left <= center_x <= cell.right
                        and cell.top <= center_y <= cell.bottom
                    ):
                        return span

        return None

    @staticmethod
    def _span_is_inside_any_table(
        span,
        tables,
    ) -> bool:
        """
        Return True when the center of a PDF span lies inside
        any detected table.

        These spans are skipped from normal text rendering
        because the table renderer recreates their content.
        """

        center_x = (
            span.left + span.right
        ) / 2

        center_y = (
            span.top + span.bottom
        ) / 2

        for table in tables:
            if (
                table.left <= center_x <= table.right
                and table.top <= center_y <= table.bottom
            ):
                return True

        return False

    @staticmethod
    def _add_image_shape(
        document_part,
        anchor_paragraph,
        image,
    ) -> None:
        """
        Add one extracted PDF image as an absolutely positioned
        Word VML image shape.
        """

        relationship_id, _ = (
            document_part.get_or_add_image(
                BytesIO(image.image_bytes)
            )
        )

        width = max(
            image.displayed_width,
            1.0,
        )

        height = max(
            image.displayed_height,
            1.0,
        )

        shape_id = (
            FixedLayoutDocxExporter._next_shape_id()
        )

        shape = (
            FixedLayoutDocxExporter
            ._create_image_shape(
                shape_id=shape_id,
                left=image.left,
                top=image.top,
                width=width,
                height=height,
            )
        )

        image_data = (
            FixedLayoutDocxExporter
            ._create_vml_element(
                "imagedata"
            )
        )

        image_data.set(
            (
                f"{{"
                f"{FixedLayoutDocxExporter.RELATIONSHIPS_NAMESPACE}"
                f"}}id"
            ),
            relationship_id,
        )

        image_data.set(
            (
                f"{{"
                f"{FixedLayoutDocxExporter.OFFICE_NAMESPACE}"
                f"}}title"
            ),
            "",
        )

        shape.append(
            image_data
        )

        pict = OxmlElement(
            "w:pict"
        )

        pict.append(
            shape
        )

        anchor_run = (
            anchor_paragraph.add_run()
        )

        anchor_run._r.append(
            pict
        )

    @staticmethod
    def _create_image_shape(
        shape_id: int,
        left: float,
        top: float,
        width: float,
        height: float,
    ):
        """
        Create an absolutely positioned VML image shape.
        """
    
        shape = (
            FixedLayoutDocxExporter
            ._create_vml_element(
                "shape"
            )
        )
    
        shape.set(
            "id",
            f"DocuMindImage{shape_id}",
        )
    
        shape.set(
            "type",
            "#_x0000_t75",
        )
    
        shape.set(
            "stroked",
            "f",
        )
    
        shape.set(
            (
                f"{{"
                f"{FixedLayoutDocxExporter.OFFICE_NAMESPACE}"
                f"}}allowincell"
            ),
            "f",
        )
    
        style = (
            "position:absolute;"
            f"margin-left:{left:.3f}pt;"
            f"margin-top:{top:.3f}pt;"
            f"width:{width:.3f}pt;"
            f"height:{height:.3f}pt;"
            f"z-index:{FixedLayoutDocxExporter.IMAGE_Z_INDEX};"
            "mso-position-horizontal-relative:page;"
            "mso-position-vertical-relative:page;"
            "mso-wrap-style:none;"
        )
    
        shape.set(
            "style",
            style,
        )
    
        wrap = (
            FixedLayoutDocxExporter
            ._create_word_2003_element(
                "wrap"
            )
        )
    
        wrap.set(
            "type",
            "none",
        )
    
        shape.append(
            wrap
        )
    
        return shape

    @staticmethod
    def _add_span_textbox(
        anchor_paragraph,
        span,
    ) -> None:
        """
        Create one absolutely positioned Word text box for
        one formatted PDF span.
        """

        left = span.left

        top = max(
            span.top
            - FixedLayoutDocxExporter.TEXTBOX_TOP_ADJUSTMENT,
            0.0,
        )

        width = max(
            span.right
            - span.left
            + FixedLayoutDocxExporter.TEXTBOX_WIDTH_PADDING,
            1.0,
        )

        pdf_span_height = max(
            span.bottom - span.top,
            1.0,
        )

        word_line_height = max(
            span.font_size
            * FixedLayoutDocxExporter.LINE_HEIGHT_FACTOR,
            pdf_span_height,
        )

        height = (
            word_line_height
            + FixedLayoutDocxExporter.TEXTBOX_HEIGHT_PADDING
        )

        shape_id = (
            FixedLayoutDocxExporter
            ._next_shape_id()
        )

        shape = (
            FixedLayoutDocxExporter
            ._create_textbox_shape(
                shape_id=shape_id,
                left=left,
                top=top,
                width=width,
                height=height,
            )
        )

        textbox = FixedLayoutDocxExporter._create_vml_element(
            "textbox"
        )

        textbox.set(
            "inset",
            "0,0,0,0",
        )

        textbox_content = OxmlElement(
            "w:txbxContent"
        )

        text_paragraph_element = OxmlElement(
            "w:p"
        )

        textbox_content.append(
            text_paragraph_element
        )

        textbox.append(
            textbox_content
        )

        shape.append(
            textbox
        )

        pict = OxmlElement(
            "w:pict"
        )

        pict.append(
            shape
        )

        anchor_run = anchor_paragraph.add_run()

        anchor_run._r.append(
            pict
        )

        text_paragraph = Paragraph(
            text_paragraph_element,
            anchor_paragraph._parent,
        )

        FixedLayoutDocxExporter._configure_text_paragraph(
            text_paragraph=text_paragraph,
            span=span,
        )

        FixedLayoutDocxExporter._add_formatted_run(
            text_paragraph=text_paragraph,
            span=span,
        )

    @staticmethod
    def _create_textbox_shape(
        shape_id: int,
        left: float,
        top: float,
        width: float,
        height: float,
    ):
        """
        Create an absolutely positioned VML text-box shape.

        VML elements are created using explicit namespace URLs
        because python-docx does not register the `v`, `o`, and
        `w10` prefixes in OxmlElement.
        """

        shape = FixedLayoutDocxExporter._create_vml_element(
            "shape"
        )

        shape.set(
            "id",
            f"DocuMindTextBox{shape_id}",
        )

        shape.set(
            "type",
            "#_x0000_t202",
        )

        shape.set(
            "stroked",
            "f",
        )

        shape.set(
            "filled",
            "f",
        )

        shape.set(
            (
                f"{{{FixedLayoutDocxExporter.OFFICE_NAMESPACE}}}"
                "allowincell"
            ),
            "f",
        )

        style = (
            "position:absolute;"
            f"margin-left:{left:.3f}pt;"
            f"margin-top:{top:.3f}pt;"
            f"width:{width:.3f}pt;"
            f"height:{height:.3f}pt;"
            f"z-index:{FixedLayoutDocxExporter.TEXT_Z_INDEX};"
            "mso-position-horizontal-relative:page;"
            "mso-position-vertical-relative:page;"
            "mso-wrap-style:none;"
            "mso-fit-shape-to-text:t;"
        )

        shape.set(
            "style",
            style,
        )

        wrap = (
            FixedLayoutDocxExporter
            ._create_word_2003_element(
                "wrap"
            )
        )

        wrap.set(
            "type",
            "none",
        )

        shape.append(
            wrap
        )

        return shape

    @staticmethod
    def _create_vml_element(
        local_name: str,
    ):
        """
        Create a VML element with all namespaces required by
        Microsoft Word's legacy text-box format.
        """

        return etree.Element(
            (
                f"{{{FixedLayoutDocxExporter.VML_NAMESPACE}}}"
                f"{local_name}"
            ),
            nsmap=FixedLayoutDocxExporter.VML_NAMESPACE_MAP,
        )

    @staticmethod
    def _create_word_2003_element(
        local_name: str,
    ):
        """
        Create an element from the legacy Microsoft Word 2003
        namespace, such as w10:wrap.
        """

        return etree.Element(
            (
                f"{{"
                f"{FixedLayoutDocxExporter.WORD_2003_NAMESPACE}"
                f"}}{local_name}"
            )
        )

    @staticmethod
    def _configure_text_paragraph(
        text_paragraph,
        span,
    ) -> None:
        """
        Remove Word paragraph spacing inside the text box.
        """

        paragraph_format = (
            text_paragraph.paragraph_format
        )

        paragraph_format.space_before = Pt(0)
        paragraph_format.space_after = Pt(0)

        paragraph_format.left_indent = Pt(0)
        paragraph_format.right_indent = Pt(0)
        paragraph_format.first_line_indent = Pt(0)

        paragraph_format.line_spacing_rule = (
            WD_LINE_SPACING.EXACTLY
        )

        paragraph_format.line_spacing = Pt(
            max(
                span.font_size
                * FixedLayoutDocxExporter.LINE_HEIGHT_FACTOR,
                span.bottom - span.top,
            )
        )

    @staticmethod
    def _add_formatted_run(
        text_paragraph,
        span,
    ) -> None:
        """
        Add editable text and preserve typography.
        """

        run = text_paragraph.add_run(
            span.text
        )

        font = run.font

        font.size = Pt(
            span.font_size
        )

        FixedLayoutDocxExporter._apply_font_name(
            run=run,
            pdf_font_name=span.font,
        )

        font.color.rgb = WordRGBColor(
            span.color.red,
            span.color.green,
            span.color.blue,
        )

        run.bold = (
            FixedLayoutDocxExporter
            ._is_bold(span.flags)
        )

        run.italic = (
            FixedLayoutDocxExporter
            ._is_italic(span.flags)
        )

    @staticmethod
    def _apply_font_name(
        run,
        pdf_font_name: str,
    ) -> None:
        """
        Resolve and apply the PDF font family to every
        Word font slot.
        """

        word_font_name = FontNameResolver.resolve(
            pdf_font_name
        )

        run.font.name = word_font_name

        run_properties = (
            run._element.get_or_add_rPr()
        )

        font_properties = (
            run_properties.get_or_add_rFonts()
        )

        font_properties.set(
            qn("w:ascii"),
            word_font_name,
        )

        font_properties.set(
            qn("w:hAnsi"),
            word_font_name,
        )

        font_properties.set(
            qn("w:eastAsia"),
            word_font_name,
        )

        font_properties.set(
            qn("w:cs"),
            word_font_name,
        )

    @staticmethod
    def _is_bold(flags: int) -> bool:
        """
        PyMuPDF flag bit 4 represents bold text.
        """

        return bool(
            flags & (1 << 4)
        )

    @staticmethod
    def _is_italic(flags: int) -> bool:
        """
        PyMuPDF flag bit 1 represents italic text.
        """

        return bool(
            flags & (1 << 1)
        )

    @staticmethod
    def _next_shape_id() -> int:
        """
        Return a unique ID for every positioned text box.
        """

        shape_id = (
            FixedLayoutDocxExporter._shape_id
        )

        FixedLayoutDocxExporter._shape_id += 1

        return shape_id