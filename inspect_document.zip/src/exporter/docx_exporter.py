from docx import Document as WordDocument
from docx.enum.text import WD_BREAK


class DocxExporter:

    @staticmethod
    def export(document, output_path):

        doc = WordDocument()

        total_pages = len(document.pages)

        for page_index, page in enumerate(document.pages):

            for block in page.blocks:

                has_text = any(
                    span.text.strip()
                    for line in block.lines
                    for span in line.spans
                )

                if not has_text:
                    continue

                paragraph = doc.add_paragraph()

                for line_index, line in enumerate(block.lines):

                    for span in line.spans:

                        if span.text == "":
                            continue

                        paragraph.add_run(span.text)

                    if line_index < len(block.lines) - 1:
                        paragraph.add_run().add_break(WD_BREAK.LINE)

            if page_index < total_pages - 1:
                doc.add_page_break()

        doc.save(output_path)