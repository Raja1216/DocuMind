from __future__ import annotations

from src.models.paragraph import Paragraph
from src.models.text_block import TextBlock


class ParagraphAnalyzer:
    """
    Version 1

    One text block = One paragraph.
    """

    @staticmethod
    def analyze(block: TextBlock) -> list[Paragraph]:

        paragraph = Paragraph()

        paragraph.lines.extend(block.lines)

        return [paragraph]