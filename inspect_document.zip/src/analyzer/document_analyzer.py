from __future__ import annotations

from src.analyzer.paragraph_analyzer import ParagraphAnalyzer
from src.models.document import Document


class DocumentAnalyzer:
    """
    Runs all analysis passes on the document.
    """

    @staticmethod
    def analyze(document: Document) -> None:

        for page in document.pages:

            for block in page.blocks:

                ParagraphAnalyzer.analyze(block)